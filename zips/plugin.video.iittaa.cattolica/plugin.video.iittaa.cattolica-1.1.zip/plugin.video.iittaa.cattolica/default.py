# -*- coding: utf-8 -*-

import os, urlparse, xbmc, xbmcaddon, xbmcgui, xbmcplugin

addon         = xbmcaddon.Addon()
addonBase     = sys.argv[0]
addonHandle   = int(sys.argv[1])
pluginArgs    = urlparse.parse_qs(sys.argv[2][1:])
addonPath     = xbmc.translatePath(addon.getAddonInfo('path'))
fanart        = os.path.join(addonPath, 'fanart.jpg')

try:    url   = pluginArgs['url'][0]
except: url   = ''
try:    mode  = pluginArgs['mode'][0]
except: mode  = None
try:    title = pluginArgs['title'][0]
except: title = ''
try:    image = pluginArgs['image'][0]
except: image = ''

def AddDir(mode, title, url, image=''):
	playable = False; folder = True
	if mode == 'ADDON':
		title = '[COLOR gold]Addon    [/COLOR] -- [COLOR white]%s[/COLOR]' % title
		link  = url
		image = 'special://home/addons/%s/icon.png' % url.split('/')[2]
	elif mode == 'LIVE':
		title = '[COLOR yellow]LIVE[/COLOR] -- [COLOR white][B]%s[/B][/COLOR]' % title
		if 'youtube.com' in url:
			ytID  = url.split('watch?v=')[1]
			link  = 'plugin://plugin.video.youtube/play/?video_id=%s' % ytID
			image = 'https://i.ytimg.com/vi/%s/maxresdefault_live.jpg' % ytID
		else:
			link  = url
		playable  = True; folder = False
	elif mode == 'LIVEADDON':
		title = '[COLOR yellow]LIVE[/COLOR] -- [COLOR white][B]%s[/B][/COLOR]' % title
		link  = url
	elif mode == 'DACAST':
		link  = url
	elif mode == 'YOUTUBE':
		title = '[COLOR red]YouTube[/COLOR] -- [COLOR silver][B]%s[/B][/COLOR]' % title
		link  = 'plugin://plugin.video.youtube/%s' % url

	li = xbmcgui.ListItem(title, iconImage=image, thumbnailImage=image)
	li.setProperty('fanart_image', fanart)
	li.setProperty('IsPlayable', str(playable))
	xbmcplugin.addDirectoryItem(handle=addonHandle, url=link, listitem=li, isFolder=folder)

def EndDir():
	xbmcplugin.endOfDirectory(addonHandle)

def MENU():
	# 'ADDON', 'LIVE', 'LIVEADDON', 'DACAST', 'YOUTUBE'
	AddDir('LIVE', 'Padre Pio TV', 'https://5698c1463445c.streamlock.net/TRPP_live/smil:bcffcc98-ac2f-4b73-b0a5-ad1bfb96d845_all.smil/master.m3u8', 'https://yt3.ggpht.com/-XuyARxZFGaw/AAAAAAAAAAI/AAAAAAAAAAA/GlZJhoM-aKM/s300-c-k-no-mo-rj-c0xffffff/photo.jpg')
	AddDir('LIVE', 'Tele Abruzzo', 'http://uk4.streamingpulse.com:1935/TeleabruzzoTV/TeleabruzzoTV/playlist.m3u8', '')
	AddDir('LIVE', 'Telepace', 'http://live.mariatvcdn.com/mariatvpoint/d36592901d5429dd7f9ec1e7bbeda8c2.sdp/playlist.m3u8', 'https://yt3.ggpht.com/-9ojQnjHybTU/AAAAAAAAAAI/AAAAAAAAAAA/ua--2_j82cE/s300-c-k-no-mo-rj-c0xffffff/photo.jpg')
	AddDir('LIVE', 'TRSP', 'http://live-fs.mariatvcdn.com/trsp/90dbedc31b9a688acdd903a6f4a5997f.sdp/index.m3u8', 'https://yt3.ggpht.com/-cfp9GmQGxec/AAAAAAAAAAI/AAAAAAAAAAA/2md59At7lOM/s300-c-k-no-mo-rj-c0xffffff/photo.jpg')
	AddDir('YOUTUBE', 'Padre Pio TV', 'user/padrepiotv/', 'https://yt3.ggpht.com/-XuyARxZFGaw/AAAAAAAAAAI/AAAAAAAAAAA/GlZJhoM-aKM/s300-c-k-no-mo-rj-c0xffffff/photo.jpg')
	AddDir('YOUTUBE', 'Telepace Roma', 'channel/UCip8-aPNJTUtCGuVjne9hLw/', 'https://yt3.ggpht.com/-qQ1RvkrwBDI/AAAAAAAAAAI/AAAAAAAAAAA/dP2RyOK_Np8/s300-c-k-no-mo-rj-c0xffffff/photo.jpg')
	AddDir('YOUTUBE', 'Telepace Verona', 'channel/UCP49yPZvTPz9PzCozvNzbUA/', 'https://yt3.ggpht.com/-9ojQnjHybTU/AAAAAAAAAAI/AAAAAAAAAAA/ua--2_j82cE/s300-c-k-no-mo-rj-c0xffffff/photo.jpg')
	AddDir('YOUTUBE', 'Teleradiopace', 'user/teleradiopace/', 'https://yt3.ggpht.com/-jXmg7nYgCQ4/AAAAAAAAAAI/AAAAAAAAAAA/nuSwoZ3vLlM/s300-c-k-no-mo-rj-c0xffffff/photo.jpg')
	AddDir('YOUTUBE', 'TRSP', 'user/tvtrsp/', 'https://yt3.ggpht.com/-cfp9GmQGxec/AAAAAAAAAAI/AAAAAAAAAAA/2md59At7lOM/s300-c-k-no-mo-rj-c0xffffff/photo.jpg')
	EndDir()

if __name__ == '__main__':
	MENU()